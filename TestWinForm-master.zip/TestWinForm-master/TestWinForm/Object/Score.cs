﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWinForm.Object
{
    class Score
    {
        //显示使用
        public string Con { get; set; }
        public string StudentName { get; set; }
        public string Mark { get; set; }

        //查询使用
        public string CourseId { get; set; }
        public string StudentId { get; set; }
    }
}
