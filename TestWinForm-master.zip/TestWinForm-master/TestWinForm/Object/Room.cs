﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWinForm.Object
{
    class Room
    {
        public string Id { get; set; }
        public string IdleTime { get; set; }
    }
}
