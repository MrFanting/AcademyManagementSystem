﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWinForm.Object
{
    class Course
    {
        public string Id { get; set; }
        public string Con { get; set; }
        public string Credit { get; set; }
        public string CourseTime { get; set; }
        public string ProgramId { get; set; }
        public string TeacherName { get; set; }
        public string Place { get; set; }
        public string RoomId { get; set; }
    }
}
