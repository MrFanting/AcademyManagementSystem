﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWinForm.Object
{
    class RoomInfo
    {
        public string Id { get; set; }
        public string Contain { get; set; }
        public string Place { get; set; }
    }
}
